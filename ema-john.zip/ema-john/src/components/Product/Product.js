import React from 'react';
import './Product.css'
const Product = (props) => {
    //console.log(props)
    return (
        <div className='product'>
            <div>
                <img src={props.product.img} alt="" />
            </div>
            <div>
                <h3 className='product-name'>{props.product.name}</h3>
                <br></br>
                <p><small>By:{props.product.seller}</small></p>
                <p>{props.product.price}</p>
                <br></br>
                <p><small>Only {props.product.stock} are available</small></p>
                <button className='main-btn' onClick={()=>props.addProduct(props.product)}>Add to cart</button>
            </div>
            
            
        </div>
    );
};

export default Product;